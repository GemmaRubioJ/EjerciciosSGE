declare module "@salesforce/apex/GameManager.updateSequence" {
  export default function updateSequence(param: {newSequence: any}): Promise<any>;
}
declare module "@salesforce/apex/GameManager.getSequence" {
  export default function getSequence(): Promise<any>;
}
